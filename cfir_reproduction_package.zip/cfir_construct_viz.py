#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CFIR construct assignment + UMAP visualization (with prototype centroids overlaid)
- Embeds sentences with ClinicalBERT or OpenAI text-embedding-3-small
- Builds CFIR prototype vectors from seed phrases
- Assigns each sentence to a CFIR construct (or UNSURE) by cosine to prototypes
- Projects sentences with UMAP (cosine) and colors by construct
- Overlays prototype centroids as large 'X' markers with labels
- (Optional) HDBSCAN subclusters within each construct
- Writes CSV: sentence, cfir_construct, subcluster
"""

import os
print(os.getenv("OPENAI_API_KEY"))


import os, json, argparse, time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------- Embedders ----------------
def embed_clinicalbert(texts, batch_size=64, normalize=True):
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("emilyalsentzer/Bio_ClinicalBERT")
    vecs = model.encode(texts, batch_size=batch_size, show_progress_bar=True, normalize_embeddings=normalize)
    V = np.asarray(vecs, dtype="float32")
    if normalize:
        V = V / (np.linalg.norm(V, axis=1, keepdims=True) + 1e-12)
    return V

def embed_openai_small(texts, normalize=True):
    from openai import OpenAI
    if "OPENAI_API_KEY" not in os.environ:
        raise SystemExit("Please export OPENAI_API_KEY before using --embedder openai_small")
    client = OpenAI()
    # For large corpora, chunk in batches if needed; one-shot for simplicity
    resp = client.embeddings.create(model="text-embedding-3-small", input=texts)
    V = np.array([d.embedding for d in resp.data], dtype="float32")
    if normalize:
        V = V / (np.linalg.norm(V, axis=1, keepdims=True) + 1e-12)
    return V

def get_embedder(name):
    if name == "clinicalbert":
        return embed_clinicalbert, 768
    elif name == "openai_small":
        return embed_openai_small, 1536
    raise SystemExit("Unknown --embedder. Use one of: clinicalbert, openai_small")

# ---------------- CFIR prototypes & assignment ----------------
def build_prototypes(cfir_lex, embed_fn):
    keys, phrases = [], []
    for k, plist in cfir_lex.items():
        for p in plist:
            keys.append(k)
            phrases.append(p)
    V = embed_fn(phrases)
    V = V / (np.linalg.norm(V, axis=1, keepdims=True) + 1e-12)
    protos = {}
    for k in sorted(set(keys)):
        idx = [i for i, kk in enumerate(keys) if kk == k]
        c = V[idx].mean(axis=0)
        c = c / (np.linalg.norm(c) + 1e-12)
        protos[k] = c
    return protos

def assign_constructs(X, protos, threshold=0.25):
    labels = list(protos.keys())
    P = np.stack([protos[k] for k in labels], axis=0)  # [K,D]
    S = np.dot(X, P.T)
  # cosine (since normalized)
    idx = np.argmax(S, axis=1)
    sc = S[np.arange(S.shape[0]), idx]
    out = [labels[i] if s >= threshold else "UNSURE" for i, s in zip(idx, sc)]
    return np.array(out, dtype=object), sc

# ---------------- UMAP & optional HDBSCAN ----------------
def fit_umap_2d(X, neighbors, min_dist, seed):
    import umap
    reducer = umap.UMAP(n_neighbors=neighbors, min_dist=min_dist, metric="cosine", random_state=seed)
    coords = reducer.fit_transform(X)
    return reducer, coords

def subcluster_within_constructs(constructs, coords, min_cluster_size, min_samples):
    import hdbscan
    subcluster = np.full((len(constructs),), fill_value=-1, dtype=int)
    constructs_unique = sorted(pd.unique(constructs))
    for construct in constructs_unique:
        if construct == "UNSURE":
            continue
        mask = (constructs == construct)
        if mask.sum() < max(5, min_cluster_size):
            continue
        coords_c = coords[mask]
        cl = hdbscan.HDBSCAN(
            min_cluster_size=min_cluster_size,
            min_samples=min_samples,
            metric="euclidean",
            cluster_selection_method="eom",
            prediction_data=False
        ).fit_predict(coords_c)
        subcluster[np.where(mask)[0]] = cl
    return subcluster

# ---------------- Plot ----------------
def plot_constructs_with_protos(coords, constructs, proto_labels, proto_coords, out_png, title_prefix=""):
    palette = {
        "Individuals": "#1f77b4",
        "Inner Setting": "#ff7f0e",
        "Outer Setting": "#2ca02c",
        "Innovation": "#d62728",
        "Process": "#9467bd",
        "UNSURE": "#7f7f7f",
    }
    fig, ax = plt.subplots(figsize=(8,7), dpi=150)
    cats = ["Individuals","Inner Setting","Outer Setting","Innovation","Process","UNSURE"]
    for c in cats:
        m = (constructs == c)
        if np.any(m):
            ax.scatter(coords[m,0], coords[m,1], s=16, alpha=0.85, label=c, c=palette.get(c,"#7f7f7f"))
    # overlay prototype markers
    for lbl, (x, y) in zip(proto_labels, proto_coords):
        ax.scatter([x],[y], marker="x", s=250, linewidths=3, c="k")
        ax.text(x+0.05, y+0.05, lbl, fontsize=12, weight="bold", color="k")
    ax.set_title(f"{title_prefix} CFIR sentence assignment (UMAP, cosine)")
    ax.set_xlabel("UMAP-1"); ax.set_ylabel("UMAP-2")
    ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.4)
    lg = ax.legend(loc="upper right", title="CFIR Buckets", frameon=True)
    try:
        lg._legend_box.align = "left"
    except Exception:
        pass
    plt.tight_layout()
    plt.savefig(out_png, bbox_inches="tight")
    print("[OK] Saved plot →", out_png)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_csv", required=True, help="CSV with sentences")
    ap.add_argument("--text_col", default="sentence")
    ap.add_argument("--cfir_lexicon_json", required=True)
    ap.add_argument("--embedder", choices=["clinicalbert","openai_small"], default="openai_small")
    ap.add_argument("--cfir_thresh", type=float, default=0.25)
    ap.add_argument("--umap_neighbors", type=int, default=30)
    ap.add_argument("--umap_min_dist", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--do_subclusters", action="store_true")
    ap.add_argument("--min_cluster_size", type=int, default=15)
    ap.add_argument("--min_samples", type=int, default=3)
    ap.add_argument("--out_csv", default="cfir_labeled_sentences.csv")
    ap.add_argument("--out_png", default="cfir_constructs_umap.png")
    args = ap.parse_args()

    # Load data
    df = pd.read_csv(args.input_csv)
    if args.text_col not in df.columns:
        raise SystemExit("Column '%s' not found in %s" % (args.text_col, args.input_csv))
    texts = df[args.text_col].astype(str).fillna("").tolist()

    # Embed
    embed_fn, _ = get_embedder(args.embedder)
    t0 = time.time()
    X = embed_fn(texts)
    print("[info] embedded %d sentences with %s in %.2fs" % (len(texts), args.embedder, time.time()-t0))

    # CFIR prototypes & assignment
    with open(args.cfir_lexicon_json, "r") as f:
        cfir_lex = json.load(f)
    protos = build_prototypes(cfir_lex, embed_fn)
    constructs, conf = assign_constructs(X, protos, threshold=args.cfir_thresh)

    # UMAP (fit so we can transform prototypes into same space)
    reducer, coords = fit_umap_2d(X, args.umap_neighbors, args.umap_min_dist, args.seed)

    # Project prototypes into UMAP space
    # (build again here to avoid reusing state)
    proto_labels = sorted(list(protos.keys()))
    P = np.stack([protos[k] for k in proto_labels], axis=0)
    proto_coords = reducer.transform(P)

    # Optional subclusters within each construct
    subcluster = np.full((len(df),), fill_value=-1, dtype=int)
    if args.do_subclusters:
        subcluster = subcluster_within_constructs(constructs, coords, args.min_cluster_size, args.min_samples)

    # Save CSV
    out = df.copy()
    out["cfir_construct"] = constructs
    out["subcluster"] = subcluster
    out.to_csv(args.out_csv, index=False, encoding="utf-8")
    print("[OK] Saved CSV →", args.out_csv)

    # Plot with prototype overlays
    plot_constructs_with_protos(coords, constructs, proto_labels, proto_coords, args.out_png, title_prefix=args.embedder)

if __name__ == "__main__":
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    main()
