#!/usr/bin/env python3
"""
Split raw interview transcripts into sentence-level rows.

This is the sentence-splitting method used to build the study's
1,461-sentence corpus (interviews.csv), with the raw transcript text
itself removed for participant privacy. Raw transcripts are
human-subjects data protected under this study's data-use terms and
are available separately under those terms, not distributed with this
code.

Usage:
    python split_transcripts_to_sentences.py --input_txt raw_transcripts.txt \
        --out_csv interviews.csv

--input_txt should be a plain-text file containing the de-identified
transcript text to split (the original pipeline concatenated all
participant transcripts into a single text block before splitting).
"""
import argparse
import re

import pandas as pd


def regex_sentence_split(text: str):
    """Split on ./?/! followed by whitespace and a capital letter or quote."""
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z"“])', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    return sentences


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_txt", required=True,
                     help="Path to a plain-text file containing the "
                          "(de-identified) transcript text to split.")
    ap.add_argument("--out_csv", default="interviews.csv",
                     help="Output CSV path (column: sentence).")
    args = ap.parse_args()

    with open(args.input_txt, "r", encoding="utf-8") as f:
        text = f.read()

    sentences = regex_sentence_split(text)

    df = pd.DataFrame({"sentence": sentences})
    df.to_csv(args.out_csv, index=False, encoding="utf-8")

    print(f"Saved {len(sentences)} sentences to {args.out_csv}")


if __name__ == "__main__":
    main()
