import pandas as pd

# Load your main CSV
df = pd.read_csv("interview_sentences.csv")   # assumes column named "sentence"

# --- Load remove list from TXT ---
with open("removed_sentences.txt", "r", encoding="utf-8") as f:
    remove_list = [line.strip().lower() for line in f if line.strip()]

# Convert to set for fast lookup
remove_set = set(remove_list)

# Create clean helper column
df["sentence_clean"] = df["sentence"].str.strip().str.lower()

# Filter out sentences that match any sentence in the txt file
filtered_df = df[~df["sentence_clean"].isin(remove_set)]

# Drop the helper column (keeps your original sentences unchanged)
filtered_df = filtered_df.drop(columns=["sentence_clean"])

# Save result
filtered_df.to_csv("filtered_sentences.csv", index=False)

print("Done! Filtered sentences saved to filtered_sentences.csv")
print(f"Original: {len(df)} | Removed: {len(remove_list)} | Final: {len(filtered_df)}")
