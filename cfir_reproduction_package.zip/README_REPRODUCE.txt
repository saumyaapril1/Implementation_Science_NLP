REPRODUCING THE CFIR CONSTRUCT / CLUSTERING ANALYSIS
======================================================

This file documents the full pipeline from raw interview transcripts to the
CFIR construct assignments, HDBSCAN/DBSCAN clustering, and UMAP visualizations
reported in the paper. See requirements.txt for the exact package versions.

DATA AVAILABILITY: this package contains CODE ONLY. The interview transcript
data (and the list of manually-removed filler sentences, which quotes the
transcripts verbatim) are human-subjects data protected under this study's
data-use terms and are NOT included here. They are available separately
under those terms. Running the pipeline end-to-end requires supplying your
own copy of these files in the locations described below.

--------------------------------------------------------------------
0. ENVIRONMENT SETUP
--------------------------------------------------------------------
Python 3.12 (this pipeline was run under Python 3.12.11 in a conda
environment named "nlp_project").

    conda create -n nlp_project python=3.12
    conda activate nlp_project
    pip install -r requirements.txt

Set your OpenAI API key as an environment variable (do NOT hardcode it in
any script or commit it to version control):

    export OPENAI_API_KEY="sk-...your-key-here..."

NOTE: two live OpenAI API keys were previously committed in plaintext in
README.txt. Those keys should be revoked/rotated in the OpenAI dashboard
and removed from README.txt (and from git history, if ever committed)
before this repository is shared as supplementary material.

--------------------------------------------------------------------
1. RAW TRANSCRIPTS -> SENTENCE-LEVEL CORPUS (1,461 sentences)
--------------------------------------------------------------------
Script:   split_transcripts_to_sentences.py
Input:    raw_transcripts.txt  (NOT INCLUDED - see DATA AVAILABILITY above;
          a plain-text file of the concatenated, de-identified transcripts)
Output:   interviews.csv (= interview_sentences.csv), column "sentence"

Transcript text is split into sentences with a regex sentence splitter:

    re.split(r'(?<=[.!?])\s+(?=[A-Z"“])', text.strip())

i.e., split after a sentence-ending punctuation mark (. ! ?) followed by
whitespace and a capital letter or opening quotation mark.

    python split_transcripts_to_sentences.py \
        --input_txt raw_transcripts.txt --out_csv interviews.csv

Applied to the original transcripts, this produces 1,461 sentence-level
rows (interviews.csv).

--------------------------------------------------------------------
2. MANUAL FILTERING -> FILTERED CORPUS (911 sentences)
--------------------------------------------------------------------
Files:    removed_sentences.txt (NOT INCLUDED - see DATA AVAILABILITY above;
          605 unique non-substantive sentences, manually curated, quoting
          the transcripts verbatim) + filtered_sentences.py
Output:   filtered_sentences.csv (911 sentences)

Sentences judged to be non-substantive backchannel/filler responses
(e.g., "Yeah.", "Not a big one.", "It's going okay.") lacking
implementation-related content were manually reviewed and listed in
removed_sentences.txt. filtered_sentences.py removes any sentence in
interviews.csv that case-insensitively matches a line in that list:

    python filtered_sentences.py

Input:  interview_sentences.csv (1,461 rows) + removed_sentences.txt
Output: filtered_sentences.csv (911 rows; 550 removed)

NOTE ON REPRODUCIBILITY: this filtering step is NOT purely algorithmic —
the *list* of sentences to remove (removed_sentences.txt) was assembled
manually, informed by (a) a general preference for excluding short/generic
backchannel responses and (b) exploratory HDBSCAN "noise" cluster exports
from early runs (see cluster_noise_sentences*.txt). It is not a fixed,
re-derivable rule; exactly reproducing the 911-sentence corpus requires the
original removed_sentences.txt file, available under this study's
data-use terms.

--------------------------------------------------------------------
3. CFIR CONSTRUCT ASSIGNMENT (prototype cosine-similarity)
--------------------------------------------------------------------
Script:      cfir_construct_viz.py
Lexicon:     cfir_lexicon.json (5 CFIR domains, 2 prototype description
             sentences each: Innovation, Outer Setting, Inner Setting,
             Individuals, Process)
Embedders:   --embedder openai_small   (OpenAI text-embedding-3-small,
                                          1536-d; embeddings generated
                                          ~December 10, 2025)
             --embedder clinicalbert   (emilyalsentzer/Bio_ClinicalBERT
                                          via sentence-transformers, 768-d)

Each sentence is embedded, compared via cosine similarity to the mean
embedding of each construct's prototype phrases, and assigned to the
best-matching construct if similarity >= --cfir_thresh, else "UNSURE".
UMAP (2D, cosine metric) is used for the scatter-plot visualization, with
optional per-construct HDBSCAN subclustering (--do_subclusters).

Example command (OpenAI, on the filtered 911-sentence corpus):

    python cfir_construct_viz.py \
      --input_csv filtered_sentences.csv --text_col sentence \
      --cfir_lexicon_json cfir_lexicon.json --embedder openai_small \
      --cfir_thresh 0.25 --umap_neighbors 30 --umap_min_dist 0.10 \
      --seed 42 --out_csv cfir_openai_small_8.csv \
      --out_png cfir_openai_small_umap_8.png

Example command (ClinicalBERT, same corpus):

    python cfir_construct_viz.py \
      --input_csv filtered_sentences.csv --text_col sentence \
      --cfir_lexicon_json cfir_lexicon.json --embedder clinicalbert \
      --cfir_thresh 0.25 --umap_neighbors 30 --umap_min_dist 0.10 \
      --seed 42 --out_csv cfir_clinicalbert_8.csv \
      --out_png cfir_clinicalbert_umap_8.png

Run on the full, unfiltered 1,461-sentence corpus (interviews.csv) to
reproduce the pre-filtering comparison plots.

--------------------------------------------------------------------
4. DENSITY-BASED CLUSTERING
--------------------------------------------------------------------
4a. DBSCAN ("direct density-based clustering")
    Script: cluster_openai_cfir_dbscan.py
    Library: sklearn.cluster.DBSCAN (scikit-learn 1.7.2)

    python cluster_openai_cfir_dbscan.py \
      --input_csv filtered_sentences.csv \
      --text_col sentence \
      --cfir_lexicon_json cfir_lexicon.json \
      --eps 0.25 --min_samples 12 \
      --umap_neighbors 30 --umap_min_dist 0.10 \
      --seed 42

    DBSCAN is run on the full 1536-d OpenAI embeddings (cosine metric).
    UMAP (2D, cosine, seed 42) is used only for visualization afterward.

4b. HDBSCAN (original embedding space)
    Script: cluster_openai_cfir_hdbscan.py
    Library: hdbscan 0.8.40 (standalone PyPI package; NOT
             sklearn.cluster.HDBSCAN)

    python cluster_openai_cfir_hdbscan.py \
      --min_cluster_size 5 --min_samples 3

    HDBSCAN params: metric="euclidean", cluster_selection_method="eom".
    Run directly on the full 1536-d OpenAI embeddings.

4c. HDBSCAN on a 15-D UMAP reduction (OpenAI embeddings)
    Script: cluster_openai_cfir_hdbscan_umap15.py

    python cluster_openai_cfir_hdbscan_umap15.py \
      --input_csv filtered_sentences.csv \
      --text_col sentence \
      --cfir_lexicon_json cfir_lexicon.json \
      --min_cluster_size 5 --min_samples 3 \
      --umap_neighbors 30 --umap_min_dist 0.10 \
      --cluster_umap_dim 15

    Embeddings are first reduced to 15 dimensions via UMAP
    (n_neighbors=30, min_dist=0.10, metric="cosine", random_state=42),
    then clustered with HDBSCAN (metric="euclidean",
    cluster_selection_method="eom", min_cluster_size=5, min_samples=3).

4d. Same as 4c, for ClinicalBERT embeddings
    Script: cluster_cfir_hdbscan_umap15_clinicalbert.py
    (identical parameters, embedder = emilyalsentzer/Bio_ClinicalBERT)

--------------------------------------------------------------------
5. OUTPUTS
--------------------------------------------------------------------
- cfir_*_umap*.png / cfir_*_with_protos.png : UMAP scatter plots colored
  by assigned CFIR construct, with prototype centroids overlaid.
- cluster_umap_*_with_cfir*.png            : UMAP scatter plots colored by
  DBSCAN/HDBSCAN cluster label, annotated with each cluster's best-matching
  CFIR construct.
- cluster_cfir_similarity_heatmap_*.png    : heatmaps of cosine similarity
  between each cluster's centroid and each CFIR prototype.
- sentences_with_clusters_*.csv            : per-sentence cluster
  assignments (column "cluster"; -1 = noise/unclustered).
- cfir_*.csv                               : per-sentence CFIR construct
  assignments (column "cfir_construct"; "UNSURE" = below threshold).
- metrics_*.json                           : embedding/clustering summary
  statistics (n_texts, noise_ratio, silhouette, Davies-Bouldin, etc.).

--------------------------------------------------------------------
6. REPRODUCIBILITY CAVEATS
--------------------------------------------------------------------
- text-embedding-3-small is a hosted, proprietary OpenAI model. OpenAI may
  silently update or deprecate model versions; embeddings for this study
  were generated on approximately December 10, 2025. Exact numerical
  reproduction of OpenAI-embedding-based results after that date is not
  guaranteed.
- UMAP and HDBSCAN are seeded (random_state/seed=42) but UMAP's approximate
  nearest-neighbor search (via pynndescent/numba) can still introduce
  minor nondeterminism across platforms/thread counts.
- The manual filtering step (Section 2) is not algorithmically re-derivable
  from the raw corpus alone; use the provided removed_sentences.txt to
  exactly reproduce the 911-sentence filtered corpus.
- The CFIR "prototype" definitions in cfir_lexicon.json consist of only
  1-2 description sentences per construct; results are sensitive to this
  lexicon and to --cfir_thresh.
